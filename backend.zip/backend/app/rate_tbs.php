<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class rate_tbs extends Model
{
    //
}
